# DEMAKO BUSINESS — Site vitrine

## Fichiers
- `index.html` : contenu et structure du site
- `style.css` : design responsive (ordinateur et mobile)
- `script.js` : menu mobile, année automatique et formulaire e-mail

## Tester sur votre appareil
Ouvrez `index.html` dans un navigateur. Les polices Google nécessitent une connexion Internet ; le site reste lisible sans elles.

## Publication gratuite avec GitHub Pages
1. Créez ou connectez-vous à un compte sur https://github.com/
2. Créez un nouveau dépôt public nommé `demako-business`.
3. Téléversez les trois fichiers `index.html`, `style.css` et `script.js` à la racine du dépôt.
4. Ouvrez **Settings → Pages**.
5. Dans **Build and deployment**, choisissez **Deploy from a branch**, branche `main`, dossier `/ (root)`, puis **Save**.
6. Après quelques minutes, GitHub affichera l'adresse publique du site dans la section Pages.

## Avant publication
- Vérifiez que le numéro WhatsApp `+225 05 66 71 84 45` est bien celui à utiliser.
- Remplacez les textes et tarifs si nécessaire.
- Les tarifs sont des propositions indicatives.
- Aucun témoignage ni projet client fictif n'a été ajouté.
- Le formulaire ouvre l'application e-mail du visiteur ; il ne stocke pas les données et ne fonctionne pas comme un formulaire serveur.
- Le nom de domaine personnalisé et certains services d'hébergement peuvent être payants. GitHub Pages permet de commencer avec une adresse gratuite `github.io`.
